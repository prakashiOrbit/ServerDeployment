export const header_data = [
  {
    "label": "pId",
    "name": "pId",
    options:{
      display:false,
   
    }
    
  },
    {
        "label": "skuId",
        "name": "skuId",
        "control": "textbox",
        "vallabelation": "alphanumeric",
        
      },
      {
        "label": "itemName",
        "name": "itemName",
        "control": "textbox",
        "vallabelation": "alphanumeric"
      },
      {
        "label": "itemCategory",
        "name": "itemCategory",
        "control": "textbox",
        "vallabelation": "alphanumeric"
      },
      {
        "label": "itemSubcategory",
        "name": "itemSubcategory",
        "control": "textbox",
        "vallabelation": "alphanumeric",
        options:{
          display:false,
       
        }
      
      },
      {
        "label": "basePrice",
        "name": "basePrice",
        "control": "textbox",
        "vallabelate": "alphanumeric"
      },
   
];

