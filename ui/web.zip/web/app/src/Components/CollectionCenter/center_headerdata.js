export const header_data = [
  {
    "label": "cId",
    "name": "cId",
    options:{
      display:false,
   
    }
    
  },
    {
        "label": "centerId",
        "name": "centerId",
        "control": "textbox",
        "vallabelation": "alphanumeric",
        
      },
      
      {
        "label": "centerName",
        "name": "centerName",
        "control": "textbox",
        "vallabelation": "phone"
      },
      {
        "label": "centerAddress",
        "name": "centerAddress",
        options:{
          display:false,
       
        }
      
      },
      {
        "label": "contact",
        "name": "contact",
        "control": "textbox",
        "vallabelate": "alphanumeric"
      },
   
];

