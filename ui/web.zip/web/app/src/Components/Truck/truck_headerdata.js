export const header_data = [
  {
    "label": "tId",
    "name": "tId",
    options:{
      display:false,
   
    }
    
  },
    {
        "label": "licenseNo",
        "name": "licenseNo",
        "control": "textbox",
        "vallabelation": "alphanumeric",
        
      },
      {
        "label": "registrationDate",
        "name": "registrationDate",
        "control": "textbox"
      },
      {
        "label": "VinNo",
        "name": "VinNo",
        "control": "textbox",
        "vallabelation": "alphanumerc",
        options:{
          display:false,
       
        }
      },
      {
        "label": "chassisNo",
        "name": "chassisNo",
        options:{
          display:false,
       
        }
      
      },
      {
        "label": "regAddress",
        "name": "regAddress",
        "control": "textbox",
        "vallabelate": "alphanumeric"
      },
   
];

