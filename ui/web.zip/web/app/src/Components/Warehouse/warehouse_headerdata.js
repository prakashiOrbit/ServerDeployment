export const header_data = [
  {
    "label": "wId",
    "name": "wId",
    options:{
      display:false,
   
    }
    
  },
    {
        "label": "address",
        "name": "address",
        "control": "textbox",
        "vallabelation": "alphanumeric",
        
      },
      {
        "label": "capacity",
        "name": "capacity",
        "control": "textbox",
        "vallabelation": "alphanumeric"
      },
      
   
];

