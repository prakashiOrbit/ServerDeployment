package com.iorbit.customer;

public class GetCustomerOrder implements java.io.Serializable{
}
