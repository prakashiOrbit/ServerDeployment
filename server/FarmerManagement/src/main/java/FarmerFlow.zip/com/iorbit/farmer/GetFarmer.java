package com.iorbit.farmer;

public class GetFarmer implements java.io.Serializable{
}
